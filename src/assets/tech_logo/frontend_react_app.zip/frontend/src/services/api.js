import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api',
})

export function setAuthToken(token) {
  api.defaults.headers.common['Authorization'] = `Bearer ${token}`
}
export function clearAuthToken() {
  delete api.defaults.headers.common['Authorization']
}

// refresh token logic can be added here if desired

export default api
