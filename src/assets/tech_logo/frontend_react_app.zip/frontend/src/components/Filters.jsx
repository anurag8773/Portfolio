import Box from '@mui/material/Box'
import TextField from '@mui/material/TextField'
import MenuItem from '@mui/material/MenuItem'
import InputAdornment from '@mui/material/InputAdornment'

export default function Filters({ categories, filters, setFilters }) {
  return (
    <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 2, mb: 3 }}>
      <TextField
        label="Search"
        value={filters.search || ''}
        onChange={e => setFilters({ ...filters, search: e.target.value })}
      />
      <TextField
        select
        label="Category"
        value={filters.category || ''}
        onChange={e => setFilters({ ...filters, category: e.target.value })}
      >
        <MenuItem value="">All</MenuItem>
        {categories.map(c => <MenuItem key={c.id} value={c.slug}>{c.name}</MenuItem>)}
      </TextField>
      <TextField
        label="Min Price"
        type="number"
        value={filters.price_min || ''}
        onChange={e => setFilters({ ...filters, price_min: e.target.value })}
        InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }}
      />
      <TextField
        label="Max Price"
        type="number"
        value={filters.price_max || ''}
        onChange={e => setFilters({ ...filters, price_max: e.target.value })}
        InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }}
      />
    </Box>
  )
}
