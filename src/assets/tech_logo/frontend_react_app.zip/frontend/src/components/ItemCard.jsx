import Card from '@mui/material/Card'
import CardActions from '@mui/material/CardActions'
import CardContent from '@mui/material/CardContent'
import CardMedia from '@mui/material/CardMedia'
import Button from '@mui/material/Button'
import Typography from '@mui/material/Typography'

export default function ItemCard({ item, onAdd }) {
  return (
    <Card>
      {item.image_url && <CardMedia component="img" height="160" image={item.image_url} alt={item.title} />}
      <CardContent>
        <Typography gutterBottom variant="h6" component="div" noWrap>{item.title}</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ minHeight: 40 }}>
          {item.description}
        </Typography>
        <Typography variant="subtitle1" sx={{ mt: 1 }}>₹ {item.price}</Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={() => onAdd(item.id)}>Add to Cart</Button>
      </CardActions>
    </Card>
  )
}
