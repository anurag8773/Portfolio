import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import TextField from '@mui/material/TextField'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Paper from '@mui/material/Paper'

export default function Login() {
  const [username, setUsername] = useState('demo')
  const [password, setPassword] = useState('demo1234')
  const [error, setError] = useState('')
  const { login } = useAuth()
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await login(username, password)
      navigate('/')
    } catch (err) {
      setError('Invalid credentials')
    }
  }

  return (
    <Paper sx={{ p: 4, maxWidth: 480, mx: 'auto' }} elevation={3}>
      <Typography variant="h5" mb={2}>Login</Typography>
      <Box component="form" onSubmit={onSubmit}>
        <TextField label="Username" fullWidth margin="normal" value={username} onChange={e => setUsername(e.target.value)} />
        <TextField label="Password" fullWidth type="password" margin="normal" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <Typography color="error" variant="body2">{error}</Typography>}
        <Button variant="contained" type="submit" sx={{ mt: 2 }} fullWidth>Login</Button>
      </Box>
      <Typography variant="body2" sx={{ mt: 2 }}>No account? <Link to="/signup">Sign up</Link></Typography>
    </Paper>
  )
}
