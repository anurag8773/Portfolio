import { useEffect, useState } from 'react'
import Grid from '@mui/material/Grid2'
import Typography from '@mui/material/Typography'
import Snackbar from '@mui/material/Snackbar'
import Alert from '@mui/material/Alert'
import api from '../services/api'
import ItemCard from '../components/ItemCard'
import Filters from '../components/Filters'
import Button from '@mui/material/Button'

export default function Listing() {
  const [categories, setCategories] = useState([])
  const [items, setItems] = useState([])
  const [filters, setFilters] = useState({})
  const [page, setPage] = useState(1)
  const [count, setCount] = useState(0)
  const [message, setMessage] = useState('')

  const fetchCategories = async () => {
    const res = await api.get('/categories/')
    setCategories(res.data)
  }

  const fetchItems = async () => {
    const params = new URLSearchParams()
    if (filters.search) params.append('search', filters.search)
    if (filters.category) params.append('category', filters.category)
    if (filters.price_min) params.append('price_min', filters.price_min)
    if (filters.price_max) params.append('price_max', filters.price_max)
    params.append('page', page)
    const res = await api.get(`/items/?${params.toString()}`)
    setItems(res.data.results || res.data)
    setCount(res.data.count || 0)
  }

  useEffect(() => { fetchCategories() }, [])
  useEffect(() => { fetchItems() }, [filters, page])

  const addToCart = async (itemId) => {
    try {
      await api.post('/cart/add/', { item_id: itemId, quantity: 1 })
      setMessage('Added to cart')
    } catch (e) {
      setMessage('Please login to add items to cart')
    }
  }

  return (
    <>
      <Typography variant="h5" mb={2}>Products</Typography>
      <Filters categories={categories} filters={filters} setFilters={setFilters} />
      <Grid container spacing={2}>
        {items.map(item => (
          <Grid key={item.id} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
            <ItemCard item={item} onAdd={addToCart} />
          </Grid>
        ))}
      </Grid>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 24 }}>
        <Button variant="outlined" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</Button>
        <Button variant="outlined" disabled={items.length < 12} onClick={() => setPage(p => p + 1)}>Next</Button>
      </div>
      <Snackbar open={!!message} autoHideDuration={2000} onClose={() => setMessage('')}>
        <Alert severity="info" variant="filled">{message}</Alert>
      </Snackbar>
    </>
  )
}
