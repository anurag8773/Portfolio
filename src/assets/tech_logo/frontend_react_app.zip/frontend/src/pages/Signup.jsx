import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import TextField from '@mui/material/TextField'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Paper from '@mui/material/Paper'

export default function Signup() {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const { signup } = useAuth()
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await signup(username, email, password)
      navigate('/')
    } catch (err) {
      setError('Sign up failed')
    }
  }

  return (
    <Paper sx={{ p: 4, maxWidth: 520, mx: 'auto' }} elevation={3}>
      <Typography variant="h5" mb={2}>Create account</Typography>
      <Box component="form" onSubmit={onSubmit}>
        <TextField label="Username" fullWidth margin="normal" value={username} onChange={e => setUsername(e.target.value)} />
        <TextField label="Email" fullWidth margin="normal" value={email} onChange={e => setEmail(e.target.value)} />
        <TextField label="Password" type="password" fullWidth margin="normal" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <Typography color="error" variant="body2">{error}</Typography>}
        <Button variant="contained" type="submit" sx={{ mt: 2 }} fullWidth>Sign up</Button>
      </Box>
      <Typography variant="body2" sx={{ mt: 2 }}>Already have an account? <Link to="/login">Login</Link></Typography>
    </Paper>
  )
}
