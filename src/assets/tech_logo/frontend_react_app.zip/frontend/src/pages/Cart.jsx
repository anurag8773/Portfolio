import { useEffect, useState } from 'react'
import api from '../services/api'
import Typography from '@mui/material/Typography'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'
import IconButton from '@mui/material/IconButton'
import DeleteIcon from '@mui/icons-material/Delete'
import TextField from '@mui/material/TextField'

export default function Cart() {
  const [cart, setCart] = useState({ items: [], total: '0.00' })

  const loadCart = async () => {
    const res = await api.get('/cart/')
    setCart(res.data)
  }

  useEffect(() => { loadCart() }, [])

  const updateQty = async (id, quantity) => {
    await api.patch(`/cart/items/${id}/`, { quantity })
    await loadCart()
  }

  const removeItem = async (id) => {
    await api.delete(`/cart/items/${id}/`)
    await loadCart()
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h5" mb={2}>Your Cart</Typography>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Item</TableCell>
              <TableCell>Price</TableCell>
              <TableCell>Quantity</TableCell>
              <TableCell>Subtotal</TableCell>
              <TableCell></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {cart.items.map(ci => (
              <TableRow key={ci.id}>
                <TableCell>{ci.item.title}</TableCell>
                <TableCell>₹ {ci.item.price}</TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    size="small"
                    value={ci.quantity}
                    onChange={e => updateQty(ci.id, Math.max(1, parseInt(e.target.value || '1', 10)))}
                    sx={{ width: 80 }}
                  />
                </TableCell>
                <TableCell>₹ {(parseFloat(ci.item.price) * ci.quantity).toFixed(2)}</TableCell>
                <TableCell>
                  <IconButton color="error" onClick={() => removeItem(ci.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            <TableRow>
              <TableCell colSpan={3} align="right"><strong>Total</strong></TableCell>
              <TableCell colSpan={2}><strong>₹ {cart.total}</strong></TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  )
}
