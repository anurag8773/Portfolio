import React, { createContext, useContext, useEffect, useState } from 'react'
import api, { setAuthToken, clearAuthToken } from '../services/api'

const AuthContext = createContext()

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [tokens, setTokens] = useState(() => {
    const t = localStorage.getItem('tokens')
    return t ? JSON.parse(t) : null
  })

  useEffect(() => {
    if (tokens?.access) {
      setAuthToken(tokens.access)
      setUser({ username: localStorage.getItem('username') || 'user' })
    } else {
      clearAuthToken()
      setUser(null)
    }
  }, [tokens])

  const login = async (username, password) => {
    const res = await api.post('/token/', { username, password })
    const payload = res.data
    localStorage.setItem('tokens', JSON.stringify(payload))
    localStorage.setItem('username', username)
    setTokens(payload)
  }

  const signup = async (username, email, password) => {
    await api.post('/auth/register/', { username, email, password })
    await login(username, password)
  }

  const logout = () => {
    localStorage.removeItem('tokens')
    localStorage.removeItem('username')
    setTokens(null)
  }

  return (
    <AuthContext.Provider value={{ user, tokens, isAuthenticated: !!tokens?.access, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
